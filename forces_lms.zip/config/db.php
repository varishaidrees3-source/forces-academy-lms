<?php
$host = 'sql107.infinityfree.com';
$user = 'if0_42324108';
$password = 'YyyfbWzbOCQM1'; 
$database = 'if0_42324108_forces_lms';

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

mysqli_set_charset($conn, 'utf8mb4');
?>